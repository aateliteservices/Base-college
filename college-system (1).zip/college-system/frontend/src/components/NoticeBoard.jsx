import { useEffect, useState } from 'react';
import client from '../api/client';

export default function NoticeBoard() {
  const [notices, setNotices] = useState(null);

  useEffect(() => {
    client.get('/notices').then((res) => setNotices(res.data.notices));
  }, []);

  if (notices === null) return null;

  return (
    <div className="notice-board">
      <h3>Notices</h3>
      {notices.length === 0 ? (
        <p className="empty-hint">Nothing posted yet.</p>
      ) : (
        <ul className="notice-list">
          {notices.map((n) => (
            <li key={n.id}>
              <div className="notice-title">{n.title}</div>
              <div className="notice-body">{n.body}</div>
              <div className="notice-meta">
                {n.author} · {new Date(n.created_at).toLocaleDateString()}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
