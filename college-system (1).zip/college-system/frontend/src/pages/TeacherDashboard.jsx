import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import client from '../api/client';
import NoticeBoard from '../components/NoticeBoard';

export default function TeacherDashboard() {
  const { user, logout } = useAuth();
  const [data, setData] = useState(null);

  useEffect(() => {
    client.get('/dashboard/teacher').then((res) => setData(res.data));
  }, []);

  return (
    <div className="dash-shell">
      <div className="dash-topbar">
        <div className="brand">Your College Name</div>
        <div className="who">
          <span>{user?.name} · Teacher</span>
          <button onClick={logout}>Sign out</button>
        </div>
      </div>
      <div className="dash-content">
        <h2>Teacher dashboard</h2>
        <p className="subtitle">{data?.message || 'Loading your overview…'}</p>
        {data?.profile ? (
          <div className="stat-grid">
            <div className="stat-card">
              <div className="value">{data.profile.employee_id}</div>
              <div className="label">Employee ID</div>
            </div>
            <div className="stat-card">
              <div className="value">{data.profile.designation || '—'}</div>
              <div className="label">Designation</div>
            </div>
          </div>
        ) : (
          <p style={{ color: 'var(--slate)' }}>
            No teacher profile is linked to this account yet — ask an admin to complete it.
          </p>
        )}
        <NoticeBoard />
      </div>
    </div>
  );
}
