import { useEffect, useState } from 'react';
import client from '../../api/client';

const emptyForm = { title: '', body: '', audience: 'all' };

export default function NoticesPage() {
  const [notices, setNotices] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState('');

  async function loadNotices() {
    const { data } = await client.get('/notices');
    setNotices(data.notices);
  }

  useEffect(() => {
    loadNotices();
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setPosting(true);
    setError('');
    try {
      await client.post('/notices', form);
      setForm(emptyForm);
      await loadNotices();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not post this notice.');
    } finally {
      setPosting(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Remove this notice?')) return;
    await client.delete(`/notices/${id}`);
    await loadNotices();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Notices</h2>
          <p className="subtitle">Post announcements to everyone, or to a specific role.</p>
        </div>
      </div>

      <div className="panel-inline">
        {error && <div className="form-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Title</label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>
          <div className="field">
            <label>Message</label>
            <textarea
              required
              rows={3}
              value={form.body}
              onChange={(e) => setForm({ ...form, body: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Audience</label>
            <select value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })}>
              <option value="all">Everyone</option>
              <option value="admin">Admins only</option>
              <option value="teacher">Teachers only</option>
              <option value="student">Students only</option>
            </select>
          </div>
          <button type="submit" className="btn-primary" disabled={posting}>
            {posting ? 'Posting…' : 'Post notice'}
          </button>
        </form>
      </div>

      <ul className="notice-list admin-notice-list">
        {notices.map((n) => (
          <li key={n.id}>
            <div>
              <div className="notice-title">{n.title}</div>
              <div className="notice-body">{n.body}</div>
              <div className="notice-meta">
                {n.author} · {n.audience} · {new Date(n.created_at).toLocaleDateString()}
              </div>
            </div>
            <button className="link-btn danger" onClick={() => handleDelete(n.id)}>Remove</button>
          </li>
        ))}
        {notices.length === 0 && <p className="empty-hint">No notices posted yet.</p>}
      </ul>
    </div>
  );
}
