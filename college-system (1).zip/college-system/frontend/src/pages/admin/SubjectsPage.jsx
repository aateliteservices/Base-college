import { useEffect, useState } from 'react';
import client from '../../api/client';

const emptyForm = { id: null, code: '', name: '', program_id: '', teacher_user_id: '' };

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [form, setForm] = useState(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function loadSubjects() {
    const { data } = await client.get('/admin/subjects');
    setSubjects(data.subjects);
  }

  useEffect(() => {
    loadSubjects();
    client.get('/admin/programs').then((res) => setPrograms(res.data.programs));
    client.get('/admin/teachers-brief').then((res) => setTeachers(res.data.teachers));
  }, []);

  function openAdd() {
    setError('');
    setForm({ ...emptyForm, program_id: programs[0]?.id || '' });
  }

  function openEdit(s) {
    setError('');
    setForm({
      id: s.id,
      code: s.code,
      name: s.name,
      program_id: s.program_id,
      teacher_user_id: s.teacher_user_id || ''
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      const payload = { ...form, teacher_user_id: form.teacher_user_id || null };
      if (form.id) {
        await client.put(`/admin/subjects/${form.id}`, payload);
      } else {
        await client.post('/admin/subjects', payload);
      }
      setForm(null);
      await loadSubjects();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save this subject.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(s) {
    if (!window.confirm(`Remove ${s.name}?`)) return;
    await client.delete(`/admin/subjects/${s.id}`);
    await loadSubjects();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Subjects & classes</h2>
          <p className="subtitle">Define subjects per program and assign a teacher to each.</p>
        </div>
        <button className="btn-primary" onClick={openAdd}>+ Add subject</button>
      </div>

      <table className="data-table">
        <thead>
          <tr>
            <th>Code</th>
            <th>Subject</th>
            <th>Program</th>
            <th>Teacher</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {subjects.map((s) => (
            <tr key={s.id}>
              <td>{s.code}</td>
              <td>{s.name}</td>
              <td>{s.program_name}</td>
              <td>{s.teacher_name || '— unassigned —'}</td>
              <td className="row-actions">
                <button className="link-btn" onClick={() => openEdit(s)}>Edit</button>
                <button className="link-btn danger" onClick={() => handleDelete(s)}>Remove</button>
              </td>
            </tr>
          ))}
          {subjects.length === 0 && (
            <tr><td colSpan={5} className="empty-hint">No subjects yet.</td></tr>
          )}
        </tbody>
      </table>

      {form && (
        <div className="panel-overlay" onClick={() => setForm(null)}>
          <div className="panel" onClick={(e) => e.stopPropagation()}>
            <h3>{form.id ? 'Edit subject' : 'Add subject'}</h3>
            {error && <div className="form-error">{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="field">
                <label>Subject code</label>
                <input required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
              </div>
              <div className="field">
                <label>Subject name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="field">
                <label>Program</label>
                <select required value={form.program_id} onChange={(e) => setForm({ ...form, program_id: e.target.value })}>
                  {programs.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Teacher (optional)</label>
                <select value={form.teacher_user_id} onChange={(e) => setForm({ ...form, teacher_user_id: e.target.value })}>
                  <option value="">— unassigned —</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>{t.name} ({t.employee_id})</option>
                  ))}
                </select>
              </div>
              <div className="panel-actions">
                <button type="button" className="btn-secondary" onClick={() => setForm(null)}>Cancel</button>
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
