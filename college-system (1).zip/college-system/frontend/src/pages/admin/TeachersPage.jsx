import { useEffect, useState } from 'react';
import client from '../../api/client';

const emptyForm = {
  id: null,
  name: '',
  email: '',
  password: '',
  employee_id: '',
  qualification: '',
  designation: '',
  phone: '',
  status: 'active'
};

export default function TeachersPage() {
  const [teachers, setTeachers] = useState([]);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function loadTeachers(q = '') {
    const { data } = await client.get('/admin/teachers', { params: q ? { search: q } : {} });
    setTeachers(data.teachers);
  }

  useEffect(() => {
    loadTeachers();
  }, []);

  function openAdd() {
    setError('');
    setForm({ ...emptyForm });
  }

  function openEdit(t) {
    setError('');
    setForm({
      id: t.id,
      name: t.name,
      email: t.email,
      password: '',
      employee_id: t.employee_id,
      qualification: t.qualification || '',
      designation: t.designation || '',
      phone: t.phone || '',
      status: t.status
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      if (form.id) {
        const payload = { ...form };
        if (!payload.password) delete payload.password;
        await client.put(`/admin/teachers/${form.id}`, payload);
      } else {
        await client.post('/admin/teachers', form);
      }
      setForm(null);
      await loadTeachers(search);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save this teacher.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(t) {
    if (!window.confirm(`Remove ${t.name}? This can't be undone.`)) return;
    await client.delete(`/admin/teachers/${t.id}`);
    await loadTeachers(search);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Teachers</h2>
          <p className="subtitle">Add, edit, and manage teaching staff accounts.</p>
        </div>
        <button className="btn-primary" onClick={openAdd}>+ Add teacher</button>
      </div>

      <form
        className="search-row"
        onSubmit={(e) => {
          e.preventDefault();
          loadTeachers(search);
        }}
      >
        <input
          placeholder="Search by name, email, or employee ID"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button type="submit" className="btn-secondary">Search</button>
      </form>

      <table className="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Employee ID</th>
            <th>Designation</th>
            <th>Qualification</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {teachers.map((t) => (
            <tr key={t.id}>
              <td>
                <div>{t.name}</div>
                <div className="row-subtext">{t.email}</div>
              </td>
              <td>{t.employee_id}</td>
              <td>{t.designation || '—'}</td>
              <td>{t.qualification || '—'}</td>
              <td><span className={`badge ${t.status}`}>{t.status}</span></td>
              <td className="row-actions">
                <button className="link-btn" onClick={() => openEdit(t)}>Edit</button>
                <button className="link-btn danger" onClick={() => handleDelete(t)}>Remove</button>
              </td>
            </tr>
          ))}
          {teachers.length === 0 && (
            <tr><td colSpan={6} className="empty-hint">No teachers yet.</td></tr>
          )}
        </tbody>
      </table>

      {form && (
        <div className="panel-overlay" onClick={() => setForm(null)}>
          <div className="panel" onClick={(e) => e.stopPropagation()}>
            <h3>{form.id ? 'Edit teacher' : 'Add teacher'}</h3>
            {error && <div className="form-error">{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="field">
                <label>Full name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="field">
                <label>Email</label>
                <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="field">
                <label>{form.id ? 'New password (leave blank to keep current)' : 'Password'}</label>
                <input
                  type="password"
                  required={!form.id}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Employee ID</label>
                <input required value={form.employee_id} onChange={(e) => setForm({ ...form, employee_id: e.target.value })} />
              </div>
              <div className="field">
                <label>Designation</label>
                <input value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} />
              </div>
              <div className="field">
                <label>Qualification</label>
                <input value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} />
              </div>
              <div className="field">
                <label>Phone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              {form.id && (
                <div className="field">
                  <label>Status</label>
                  <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                    <option value="active">Active</option>
                    <option value="disabled">Disabled</option>
                  </select>
                </div>
              )}
              <div className="panel-actions">
                <button type="button" className="btn-secondary" onClick={() => setForm(null)}>Cancel</button>
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
