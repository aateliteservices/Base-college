import { useEffect, useState } from 'react';
import client from '../../api/client';

const emptyForm = {
  id: null,
  name: '',
  email: '',
  password: '',
  registration_no: '',
  program_id: '',
  session_year: '',
  phone: '',
  status: 'active'
};

export default function StudentsPage() {
  const [students, setStudents] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function loadStudents(q = '') {
    const { data } = await client.get('/admin/students', { params: q ? { search: q } : {} });
    setStudents(data.students);
  }

  useEffect(() => {
    loadStudents();
    client.get('/admin/programs').then((res) => setPrograms(res.data.programs));
  }, []);

  function openAdd() {
    setError('');
    setForm({ ...emptyForm, program_id: programs[0]?.id || '' });
  }

  function openEdit(s) {
    setError('');
    setForm({
      id: s.id,
      name: s.name,
      email: s.email,
      password: '',
      registration_no: s.registration_no,
      program_id: s.program_id,
      session_year: s.session_year || '',
      phone: s.phone || '',
      status: s.status
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      if (form.id) {
        const payload = { ...form };
        if (!payload.password) delete payload.password;
        await client.put(`/admin/students/${form.id}`, payload);
      } else {
        await client.post('/admin/students', form);
      }
      setForm(null);
      await loadStudents(search);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save this student.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(s) {
    if (!window.confirm(`Remove ${s.name}? This can't be undone.`)) return;
    await client.delete(`/admin/students/${s.id}`);
    await loadStudents(search);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Students</h2>
          <p className="subtitle">Add, edit, and manage student accounts.</p>
        </div>
        <button className="btn-primary" onClick={openAdd}>+ Add student</button>
      </div>

      <form
        className="search-row"
        onSubmit={(e) => {
          e.preventDefault();
          loadStudents(search);
        }}
      >
        <input
          placeholder="Search by name, email, or registration no."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button type="submit" className="btn-secondary">Search</button>
      </form>

      <table className="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Registration No.</th>
            <th>Program</th>
            <th>Session</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>
                <div>{s.name}</div>
                <div className="row-subtext">{s.email}</div>
              </td>
              <td>{s.registration_no}</td>
              <td>{s.program_name}</td>
              <td>{s.session_year || '—'}</td>
              <td><span className={`badge ${s.status}`}>{s.status}</span></td>
              <td className="row-actions">
                <button className="link-btn" onClick={() => openEdit(s)}>Edit</button>
                <button className="link-btn danger" onClick={() => handleDelete(s)}>Remove</button>
              </td>
            </tr>
          ))}
          {students.length === 0 && (
            <tr><td colSpan={6} className="empty-hint">No students yet.</td></tr>
          )}
        </tbody>
      </table>

      {form && (
        <div className="panel-overlay" onClick={() => setForm(null)}>
          <div className="panel" onClick={(e) => e.stopPropagation()}>
            <h3>{form.id ? 'Edit student' : 'Add student'}</h3>
            {error && <div className="form-error">{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="field">
                <label>Full name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="field">
                <label>Email</label>
                <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="field">
                <label>{form.id ? 'New password (leave blank to keep current)' : 'Password'}</label>
                <input
                  type="password"
                  required={!form.id}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Registration number</label>
                <input required value={form.registration_no} onChange={(e) => setForm({ ...form, registration_no: e.target.value })} />
              </div>
              <div className="field">
                <label>Program</label>
                <select required value={form.program_id} onChange={(e) => setForm({ ...form, program_id: e.target.value })}>
                  {programs.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Session (e.g. 2025-2027)</label>
                <input value={form.session_year} onChange={(e) => setForm({ ...form, session_year: e.target.value })} />
              </div>
              <div className="field">
                <label>Phone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              {form.id && (
                <div className="field">
                  <label>Status</label>
                  <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                    <option value="active">Active</option>
                    <option value="disabled">Disabled</option>
                  </select>
                </div>
              )}
              <div className="panel-actions">
                <button type="button" className="btn-secondary" onClick={() => setForm(null)}>Cancel</button>
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
