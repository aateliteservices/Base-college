import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ROLES = [
  { key: 'admin', label: 'Administrator' },
  { key: 'teacher', label: 'Teacher' },
  { key: 'student', label: 'Student' }
];

export default function Login() {
  const [role, setRole] = useState('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const user = await login(email, password);
      if (user.role !== role) {
        setError(
          `This account is registered as ${user.role}, not ${role}. Taking you to the right dashboard.`
        );
      }
      navigate(`/${user.role}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  const activeRoleLabel = ROLES.find((r) => r.key === role).label;

  return (
    <div className="auth-screen">
      <div className="auth-brand">
        <svg className="crest" viewBox="0 0 56 56" fill="none" aria-hidden="true">
          <circle cx="28" cy="28" r="26" stroke="#B8892B" strokeWidth="1.5" />
          <path d="M28 14 L40 20 V32 C40 40 34 44 28 46 C22 44 16 40 16 32 V20 Z" stroke="#B8892B" strokeWidth="1.5" />
          <path d="M22 27 L27 32 L36 22" stroke="#FAF7F0" strokeWidth="1.5" fill="none" />
        </svg>
        <h1>Your College Name</h1>
        <p>One portal for admissions, faculty, and every student record — sign in with the account issued to you.</p>
        <div className="motto">Knowledge · Discipline · Service</div>
      </div>

      <div className="auth-form-panel">
        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="role-tabs">
            {ROLES.map((r) => (
              <button
                type="button"
                key={r.key}
                className={`role-tab ${role === r.key ? 'active' : ''}`}
                onClick={() => setRole(r.key)}
              >
                {r.label}
              </button>
            ))}
          </div>

          {error && <div className="form-error">{error}</div>}

          <div className="field">
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="username"
            />
          </div>

          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </div>

          <button className="auth-submit" type="submit" disabled={submitting}>
            {submitting ? 'Signing in…' : `Sign in as ${activeRoleLabel}`}
          </button>
        </form>
      </div>
    </div>
  );
}
