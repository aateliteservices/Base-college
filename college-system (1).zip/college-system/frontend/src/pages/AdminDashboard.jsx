import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import client from '../api/client';
import AdminLayout from '../components/AdminLayout';
import NoticeBoard from '../components/NoticeBoard';

export default function AdminDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    client.get('/dashboard/admin').then((res) => setData(res.data));
  }, []);

  return (
    <AdminLayout>
      <h2>Overview</h2>
      <p className="subtitle">{data?.message || 'Loading your overview…'}</p>

      {data && (
        <div className="stat-grid">
          <div className="stat-card">
            <div className="value">{data.stats.students}</div>
            <div className="label">Students enrolled</div>
          </div>
          <div className="stat-card">
            <div className="value">{data.stats.teachers}</div>
            <div className="label">Teaching staff</div>
          </div>
        </div>
      )}

      <div className="quick-links">
        <Link to="/admin/students" className="quick-link">Manage students →</Link>
        <Link to="/admin/teachers" className="quick-link">Manage teachers →</Link>
        <Link to="/admin/subjects" className="quick-link">Manage subjects & classes →</Link>
        <Link to="/admin/notices" className="quick-link">Post a notice →</Link>
      </div>

      <NoticeBoard />
    </AdminLayout>
  );
}
