import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import client from '../api/client';
import NoticeBoard from '../components/NoticeBoard';

export default function StudentDashboard() {
  const { user, logout } = useAuth();
  const [data, setData] = useState(null);

  useEffect(() => {
    client.get('/dashboard/student').then((res) => setData(res.data));
  }, []);

  return (
    <div className="dash-shell">
      <div className="dash-topbar">
        <div className="brand">Your College Name</div>
        <div className="who">
          <span>{user?.name} · Student</span>
          <button onClick={logout}>Sign out</button>
        </div>
      </div>
      <div className="dash-content">
        <h2>Student dashboard</h2>
        <p className="subtitle">{data?.message || 'Loading your overview…'}</p>
        {data?.profile ? (
          <div className="stat-grid">
            <div className="stat-card">
              <div className="value">{data.profile.registration_no}</div>
              <div className="label">Registration No.</div>
            </div>
            <div className="stat-card">
              <div className="value">{data.profile.program}</div>
              <div className="label">Program</div>
            </div>
            <div className="stat-card">
              <div className="value">{data.profile.session_year || '—'}</div>
              <div className="label">Session</div>
            </div>
          </div>
        ) : (
          <p style={{ color: 'var(--slate)' }}>
            No student profile is linked to this account yet — ask an admin to complete it.
          </p>
        )}
        <NoticeBoard />
      </div>
    </div>
  );
}
