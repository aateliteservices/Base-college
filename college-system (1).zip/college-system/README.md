# College Management System — Phase 1: Core Auth & Database

This is the foundation of the full system you outlined: a Node.js/Express +
MySQL backend and a React (Vite) frontend, with working login and role-based
access for **Admin**, **Teacher**, and **Student**. Everything else (public
site pages, attendance, exams, fees, admin CRUD screens, etc.) plugs into
this foundation in later phases — see the roadmap at the bottom.

## What's included right now

**Phase 1 — auth & database**
- MySQL schema: `users`, `admins`, `teachers`, `students`, `programs`
  (seeded with FCS, ICS, FSc Pre-Engineering, FSc Pre-Medical), `refresh_tokens`
- Express API with JWT access tokens + httpOnly-cookie refresh tokens, bcrypt
  password hashing, and role-gated routes
- A login screen with role selection, and three protected dashboards
  (Admin / Teacher / Student) that pull real data from the API

**Phase 2 — admin management panel (new)**
- `subjects` and `notices` tables (`backend/database/phase2_management.sql`)
- Full **Student CRUD** — search, add, edit, disable/enable, remove, reset password
- Full **Teacher CRUD** — same, plus qualification/designation/phone
- **Subjects & classes** — create subjects per program, assign a teacher to each
- **Notices** — admin posts announcements to everyone or one role; a live
  notice board now shows on all three dashboards
- A proper admin sidebar (Dashboard / Students / Teachers / Subjects / Notices)
  replacing the bare dashboard from Phase 1

Everything below in the roadmap (attendance, exams/results, fees, admissions,
timetable, library, assignments, and the public marketing site) is still
**not implemented yet** — this update focused on the management core those
modules will build on top of.

## 1. Set up the database

1. Install MySQL locally (or use a hosted MySQL instance).
2. Run the schema, then the phase 2 additions:
   ```bash
   mysql -u root -p < backend/database/schema.sql
   mysql -u root -p < backend/database/phase2_management.sql
   ```
   This creates the `college_system` database, all core tables (including
   `subjects` and `notices`), and seeds the four programs.

## 2. Set up the backend

```bash
cd backend
cp .env.example .env      # then edit DB credentials and set real JWT secrets
npm install
npm run seed:admin        # creates the first admin using SEED_ADMIN_* from .env
npm run dev                # starts the API on http://localhost:5000
```

Generate strong values for `JWT_ACCESS_SECRET` and `JWT_REFRESH_SECRET`
(e.g. `openssl rand -hex 32`) — don't ship the placeholders.

You can now create teacher/student accounts from the **admin UI** (Students /
Teachers pages in the sidebar) once you've logged in as admin — the CLI
scripts below still work too, useful for quick seeding:
```bash
npm run create:user -- teacher "Aisha Khan" aisha@example.com Passw0rd! EMP-001 "MSc Computer Science" "Lecturer"
npm run create:user -- student "Ali Raza" ali@example.com Passw0rd! REG-2026-001 FCS "2025-2027"
```
(Program codes: `FCS`, `ICS`, `PRE_ENG`, `PRE_MED`.)

## 3. Set up the frontend

```bash
cd frontend
cp .env.example .env      # points at the local API by default
npm install
npm run dev                # starts the app on http://localhost:3000
```

Open `http://localhost:3000/login`, sign in with the admin/teacher/student
account you created, and you'll land on the matching dashboard.

## Deployment (since you're on Node.js/React, not PHP)

InfinityFree only runs PHP, so it won't work for this stack. Reasonable
free/low-cost options:

- **Backend + MySQL:** Railway, Render, or Fly.io (all support Node.js and
  provision a MySQL database)
- **Frontend:** Vercel or Netlify (build command `npm run build`, output
  folder `dist`)
- Set `CLIENT_URL` on the backend and `VITE_API_URL` on the frontend to the
  real deployed URLs, and make sure cookies use `secure: true` in production
  (already handled via `NODE_ENV=production`).

## Customizing the branding

The login and dashboard pages currently say "Your College Name" as a
placeholder — replace it in `frontend/src/pages/Login.jsx` and the three
dashboard files once you've got a name/logo, or tell me the college's actual
name and I'll wire it in along with a proper logo mark.

## Roadmap — mapping back to your full spec

Done: **database + login/auth core** (Phase 1) and **admin management panel**
— student/teacher/subject CRUD + notices (Phase 2). Suggested next phases,
each buildable and testable on its own:

1. **Attendance module** — teacher marks attendance per subject, students
   see their own percentage
2. **Examinations & results** — date sheets, marks entry, grade/GPA calculation
3. **Fees module** — fee structure, challans, payment tracking
4. **Admissions workflow** — online application, merit lists, status tracking
5. **Timetable, assignments, and library**
6. **Public website** — Home, About, Programs (FCS/ICS/Pre-Engineering/Pre-Medical),
   Admissions, News & Events, Gallery, Contact

Tell me which phase to build next and I'll continue in the same pattern:
working code, a short setup step, then you test it before we move on.
