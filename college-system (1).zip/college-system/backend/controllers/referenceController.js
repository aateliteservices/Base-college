const pool = require('../config/db');

async function listPrograms(req, res) {
  const [rows] = await pool.query('SELECT id, code, name FROM programs ORDER BY name');
  res.json({ programs: rows });
}

async function listTeachersBrief(req, res) {
  const [rows] = await pool.query(
    `SELECT u.id, u.name, t.employee_id
     FROM users u JOIN teachers t ON t.user_id = u.id
     WHERE u.status = 'active'
     ORDER BY u.name`
  );
  res.json({ teachers: rows });
}

module.exports = { listPrograms, listTeachersBrief };
