const bcrypt = require('bcrypt');
const pool = require('../config/db');

async function list(req, res) {
  const search = req.query.search ? `%${req.query.search}%` : null;
  const params = [];
  let sql = `
    SELECT u.id, u.name, u.email, u.status, t.employee_id, t.qualification, t.designation, t.phone
    FROM users u
    JOIN teachers t ON t.user_id = u.id
    WHERE u.role = 'teacher'
  `;
  if (search) {
    sql += ' AND (u.name LIKE ? OR u.email LIKE ? OR t.employee_id LIKE ?)';
    params.push(search, search, search);
  }
  sql += ' ORDER BY u.created_at DESC';
  const [rows] = await pool.query(sql, params);
  res.json({ teachers: rows });
}

async function create(req, res) {
  const { name, email, password, employee_id, qualification, designation, phone } = req.body;
  if (!name || !email || !password || !employee_id) {
    return res.status(400).json({ message: 'Name, email, password, and employee ID are required.' });
  }

  const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (existing[0]) {
    return res.status(409).json({ message: 'An account with that email already exists.' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const hash = await bcrypt.hash(password, 10);
    const [result] = await conn.query(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, "teacher")',
      [name, email, hash]
    );
    await conn.query(
      'INSERT INTO teachers (user_id, employee_id, qualification, designation, phone) VALUES (?, ?, ?, ?, ?)',
      [result.insertId, employee_id, qualification || null, designation || null, phone || null]
    );
    await conn.commit();
    res.status(201).json({ message: 'Teacher account created.', id: result.insertId });
  } catch (err) {
    await conn.rollback();
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'That employee ID is already in use.' });
    }
    throw err;
  } finally {
    conn.release();
  }
}

async function update(req, res) {
  const { id } = req.params;
  const { name, email, status, employee_id, qualification, designation, phone, password } = req.body;

  const [rows] = await pool.query('SELECT id FROM users WHERE id = ? AND role = "teacher"', [id]);
  if (!rows[0]) return res.status(404).json({ message: 'Teacher not found.' });

  await pool.query(
    'UPDATE users SET name = COALESCE(?, name), email = COALESCE(?, email), status = COALESCE(?, status) WHERE id = ?',
    [name || null, email || null, status || null, id]
  );

  if (password) {
    const hash = await bcrypt.hash(password, 10);
    await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, id]);
  }

  await pool.query(
    `UPDATE teachers SET
       employee_id = COALESCE(?, employee_id),
       qualification = COALESCE(?, qualification),
       designation = COALESCE(?, designation),
       phone = COALESCE(?, phone)
     WHERE user_id = ?`,
    [employee_id || null, qualification || null, designation || null, phone || null, id]
  );

  res.json({ message: 'Teacher updated.' });
}

async function remove(req, res) {
  const { id } = req.params;
  const [result] = await pool.query('DELETE FROM users WHERE id = ? AND role = "teacher"', [id]);
  if (result.affectedRows === 0) return res.status(404).json({ message: 'Teacher not found.' });
  res.json({ message: 'Teacher removed.' });
}

module.exports = { list, create, update, remove };
