const pool = require('../config/db');

async function list(req, res) {
  const [rows] = await pool.query(`
    SELECT sub.id, sub.code, sub.name, sub.program_id, p.name AS program_name,
           sub.teacher_user_id, u.name AS teacher_name
    FROM subjects sub
    JOIN programs p ON p.id = sub.program_id
    LEFT JOIN users u ON u.id = sub.teacher_user_id
    ORDER BY p.name, sub.name
  `);
  res.json({ subjects: rows });
}

async function create(req, res) {
  const { code, name, program_id, teacher_user_id } = req.body;
  if (!code || !name || !program_id) {
    return res.status(400).json({ message: 'Code, name, and program are required.' });
  }
  try {
    const [result] = await pool.query(
      'INSERT INTO subjects (code, name, program_id, teacher_user_id) VALUES (?, ?, ?, ?)',
      [code, name, program_id, teacher_user_id || null]
    );
    res.status(201).json({ message: 'Subject created.', id: result.insertId });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'That subject code already exists for this program.' });
    }
    throw err;
  }
}

async function update(req, res) {
  const { id } = req.params;
  const { code, name, program_id, teacher_user_id } = req.body;

  const [rows] = await pool.query('SELECT id FROM subjects WHERE id = ?', [id]);
  if (!rows[0]) return res.status(404).json({ message: 'Subject not found.' });

  await pool.query(
    `UPDATE subjects SET
       code = COALESCE(?, code),
       name = COALESCE(?, name),
       program_id = COALESCE(?, program_id),
       teacher_user_id = ?
     WHERE id = ?`,
    [code || null, name || null, program_id || null, teacher_user_id || null, id]
  );

  res.json({ message: 'Subject updated.' });
}

async function remove(req, res) {
  const { id } = req.params;
  const [result] = await pool.query('DELETE FROM subjects WHERE id = ?', [id]);
  if (result.affectedRows === 0) return res.status(404).json({ message: 'Subject not found.' });
  res.json({ message: 'Subject removed.' });
}

module.exports = { list, create, update, remove };
