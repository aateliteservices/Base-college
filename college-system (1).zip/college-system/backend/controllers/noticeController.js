const pool = require('../config/db');

async function list(req, res) {
  const { role } = req.user;
  const [rows] = await pool.query(
    `SELECT n.id, n.title, n.body, n.audience, n.created_at, u.name AS author
     FROM notices n
     JOIN users u ON u.id = n.created_by
     WHERE n.audience = 'all' OR n.audience = ?
     ORDER BY n.created_at DESC
     LIMIT 50`,
    [role]
  );
  res.json({ notices: rows });
}

async function create(req, res) {
  const { title, body, audience } = req.body;
  if (!title || !body) {
    return res.status(400).json({ message: 'Title and body are required.' });
  }
  const validAudience = ['all', 'admin', 'teacher', 'student'].includes(audience) ? audience : 'all';
  const [result] = await pool.query(
    'INSERT INTO notices (title, body, audience, created_by) VALUES (?, ?, ?, ?)',
    [title, body, validAudience, req.user.id]
  );
  res.status(201).json({ message: 'Notice posted.', id: result.insertId });
}

async function remove(req, res) {
  const { id } = req.params;
  const [result] = await pool.query('DELETE FROM notices WHERE id = ?', [id]);
  if (result.affectedRows === 0) return res.status(404).json({ message: 'Notice not found.' });
  res.json({ message: 'Notice removed.' });
}

module.exports = { list, create, remove };
