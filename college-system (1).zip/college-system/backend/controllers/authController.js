const bcrypt = require('bcrypt');
const pool = require('../config/db');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');

const REFRESH_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  maxAge: 7 * 24 * 60 * 60 * 1000
};

async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
  const user = rows[0];

  if (!user || user.status !== 'active') {
    return res.status(401).json({ message: 'Invalid email or password.' });
  }

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) {
    return res.status(401).json({ message: 'Invalid email or password.' });
  }

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  await pool.query(
    'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, ?)',
    [user.id, refreshToken, expiresAt]
  );

  res.cookie('refreshToken', refreshToken, REFRESH_COOKIE_OPTIONS);
  res.json({
    accessToken,
    user: { id: user.id, name: user.name, email: user.email, role: user.role }
  });
}

async function refresh(req, res) {
  const token = req.cookies.refreshToken;
  if (!token) return res.status(401).json({ message: 'Not authenticated.' });

  try {
    const payload = verifyRefreshToken(token);
    const [rows] = await pool.query(
      'SELECT * FROM refresh_tokens WHERE token = ? AND user_id = ?',
      [token, payload.id]
    );
    if (!rows[0]) return res.status(401).json({ message: 'Session no longer valid.' });

    const [userRows] = await pool.query('SELECT * FROM users WHERE id = ?', [payload.id]);
    const user = userRows[0];
    if (!user || user.status !== 'active') {
      return res.status(401).json({ message: 'Account is not active.' });
    }

    const accessToken = signAccessToken(user);
    res.json({
      accessToken,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    return res.status(401).json({ message: 'Session expired. Please log in again.' });
  }
}

async function logout(req, res) {
  const token = req.cookies.refreshToken;
  if (token) {
    await pool.query('DELETE FROM refresh_tokens WHERE token = ?', [token]);
  }
  res.clearCookie('refreshToken', REFRESH_COOKIE_OPTIONS);
  res.json({ message: 'Logged out.' });
}

async function me(req, res) {
  const [rows] = await pool.query(
    'SELECT id, name, email, role FROM users WHERE id = ?',
    [req.user.id]
  );
  if (!rows[0]) return res.status(404).json({ message: 'User not found.' });
  res.json({ user: rows[0] });
}

module.exports = { login, refresh, logout, me };
