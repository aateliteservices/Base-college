const bcrypt = require('bcrypt');
const pool = require('../config/db');

async function list(req, res) {
  const search = req.query.search ? `%${req.query.search}%` : null;
  const params = [];
  let sql = `
    SELECT u.id, u.name, u.email, u.status, s.registration_no, s.session_year, s.phone,
           s.program_id, p.name AS program_name
    FROM users u
    JOIN students s ON s.user_id = u.id
    JOIN programs p ON p.id = s.program_id
    WHERE u.role = 'student'
  `;
  if (search) {
    sql += ' AND (u.name LIKE ? OR u.email LIKE ? OR s.registration_no LIKE ?)';
    params.push(search, search, search);
  }
  sql += ' ORDER BY u.created_at DESC';
  const [rows] = await pool.query(sql, params);
  res.json({ students: rows });
}

async function create(req, res) {
  const { name, email, password, registration_no, program_id, session_year, phone } = req.body;
  if (!name || !email || !password || !registration_no || !program_id) {
    return res.status(400).json({ message: 'Name, email, password, registration number, and program are required.' });
  }

  const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (existing[0]) {
    return res.status(409).json({ message: 'An account with that email already exists.' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const hash = await bcrypt.hash(password, 10);
    const [result] = await conn.query(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, "student")',
      [name, email, hash]
    );
    await conn.query(
      'INSERT INTO students (user_id, registration_no, program_id, session_year, phone) VALUES (?, ?, ?, ?, ?)',
      [result.insertId, registration_no, program_id, session_year || null, phone || null]
    );
    await conn.commit();
    res.status(201).json({ message: 'Student account created.', id: result.insertId });
  } catch (err) {
    await conn.rollback();
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'That registration number is already in use.' });
    }
    throw err;
  } finally {
    conn.release();
  }
}

async function update(req, res) {
  const { id } = req.params;
  const { name, email, status, registration_no, program_id, session_year, phone, password } = req.body;

  const [rows] = await pool.query('SELECT id FROM users WHERE id = ? AND role = "student"', [id]);
  if (!rows[0]) return res.status(404).json({ message: 'Student not found.' });

  await pool.query(
    'UPDATE users SET name = COALESCE(?, name), email = COALESCE(?, email), status = COALESCE(?, status) WHERE id = ?',
    [name || null, email || null, status || null, id]
  );

  if (password) {
    const hash = await bcrypt.hash(password, 10);
    await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, id]);
  }

  await pool.query(
    `UPDATE students SET
       registration_no = COALESCE(?, registration_no),
       program_id = COALESCE(?, program_id),
       session_year = COALESCE(?, session_year),
       phone = COALESCE(?, phone)
     WHERE user_id = ?`,
    [registration_no || null, program_id || null, session_year || null, phone || null, id]
  );

  res.json({ message: 'Student updated.' });
}

async function remove(req, res) {
  const { id } = req.params;
  const [result] = await pool.query('DELETE FROM users WHERE id = ? AND role = "student"', [id]);
  if (result.affectedRows === 0) return res.status(404).json({ message: 'Student not found.' });
  res.json({ message: 'Student removed.' });
}

module.exports = { list, create, update, remove };
