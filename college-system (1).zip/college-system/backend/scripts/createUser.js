require('dotenv').config();
const bcrypt = require('bcrypt');
const pool = require('../config/db');

// Examples:
//   node scripts/createUser.js teacher "Aisha Khan" aisha@example.com Passw0rd! EMP-001 "MSc Computer Science" "Lecturer"
//   node scripts/createUser.js student "Ali Raza" ali@example.com Passw0rd! REG-2026-001 FCS "2025-2027"

async function main() {
  const [role, name, email, password, a, b, c] = process.argv.slice(2);

  if (!['teacher', 'student'].includes(role)) {
    console.error('First argument must be "teacher" or "student".');
    process.exit(1);
  }
  if (!name || !email || !password) {
    console.error('Usage: node scripts/createUser.js <teacher|student> <name> <email> <password> ...');
    process.exit(1);
  }

  const hash = await bcrypt.hash(password, 10);
  const [result] = await pool.query(
    'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
    [name, email, hash, role]
  );
  const userId = result.insertId;

  if (role === 'teacher') {
    const [employeeId, qualification, designation] = [a, b, c];
    if (!employeeId) {
      console.error('Teacher accounts need an employee ID as the 5th argument.');
      process.exit(1);
    }
    await pool.query(
      'INSERT INTO teachers (user_id, employee_id, qualification, designation) VALUES (?, ?, ?, ?)',
      [userId, employeeId, qualification || null, designation || null]
    );
  } else {
    const [registrationNo, programCode, sessionYear] = [a, b, c];
    if (!registrationNo || !programCode) {
      console.error('Student accounts need a registration number and program code (FCS, ICS, PRE_ENG, PRE_MED).');
      process.exit(1);
    }
    const [[program]] = await pool.query('SELECT id FROM programs WHERE code = ?', [programCode]);
    if (!program) {
      console.error(`Unknown program code "${programCode}". Use FCS, ICS, PRE_ENG, or PRE_MED.`);
      process.exit(1);
    }
    await pool.query(
      'INSERT INTO students (user_id, registration_no, program_id, session_year) VALUES (?, ?, ?, ?)',
      [userId, registrationNo, program.id, sessionYear || null]
    );
  }

  console.log(`${role} account created: ${email}`);
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
