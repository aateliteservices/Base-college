const express = require('express');
const router = express.Router();
const { requireAuth, requireRole } = require('../middleware/auth');
const pool = require('../config/db');

router.get('/admin', requireAuth, requireRole('admin'), async (req, res) => {
  const [[{ count: studentCount }]] = await pool.query('SELECT COUNT(*) as count FROM students');
  const [[{ count: teacherCount }]] = await pool.query('SELECT COUNT(*) as count FROM teachers');
  res.json({
    message: `Welcome, ${req.user.name}.`,
    stats: { students: studentCount, teachers: teacherCount }
  });
});

router.get('/teacher', requireAuth, requireRole('teacher'), async (req, res) => {
  const [rows] = await pool.query(
    'SELECT employee_id, designation, qualification FROM teachers WHERE user_id = ?',
    [req.user.id]
  );
  res.json({ message: `Welcome, ${req.user.name}.`, profile: rows[0] || null });
});

router.get('/student', requireAuth, requireRole('student'), async (req, res) => {
  const [rows] = await pool.query(
    `SELECT s.registration_no, s.session_year, p.name AS program
     FROM students s JOIN programs p ON s.program_id = p.id
     WHERE s.user_id = ?`,
    [req.user.id]
  );
  res.json({ message: `Welcome, ${req.user.name}.`, profile: rows[0] || null });
});

module.exports = router;
