const express = require('express');
const router = express.Router();
const { requireAuth, requireRole } = require('../middleware/auth');

const students = require('../controllers/studentController');
const teachers = require('../controllers/teacherController');
const subjects = require('../controllers/subjectController');
const reference = require('../controllers/referenceController');

router.use(requireAuth, requireRole('admin'));

router.get('/students', students.list);
router.post('/students', students.create);
router.put('/students/:id', students.update);
router.delete('/students/:id', students.remove);

router.get('/teachers', teachers.list);
router.post('/teachers', teachers.create);
router.put('/teachers/:id', teachers.update);
router.delete('/teachers/:id', teachers.remove);

router.get('/subjects', subjects.list);
router.post('/subjects', subjects.create);
router.put('/subjects/:id', subjects.update);
router.delete('/subjects/:id', subjects.remove);

router.get('/programs', reference.listPrograms);
router.get('/teachers-brief', reference.listTeachersBrief);

module.exports = router;
