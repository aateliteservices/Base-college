const express = require('express');
const router = express.Router();
const { requireAuth, requireRole } = require('../middleware/auth');
const notices = require('../controllers/noticeController');

router.get('/', requireAuth, notices.list);
router.post('/', requireAuth, requireRole('admin'), notices.create);
router.delete('/:id', requireAuth, requireRole('admin'), notices.remove);

module.exports = router;
