-- Phase 2 — Management & Notices
-- Run after schema.sql

USE college_system;

CREATE TABLE subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(150) NOT NULL,
    program_id INT NOT NULL,
    teacher_user_id INT NULL,           -- assigned teacher, optional
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_code_per_program (code, program_id),
    FOREIGN KEY (program_id) REFERENCES programs(id),
    FOREIGN KEY (teacher_user_id) REFERENCES teachers(user_id) ON DELETE SET NULL
);

CREATE TABLE notices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    audience ENUM('all', 'admin', 'teacher', 'student') NOT NULL DEFAULT 'all',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);
