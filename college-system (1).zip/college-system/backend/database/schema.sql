-- College Management System — Core Schema (Phase 1: Roles & Auth)
-- Later phases add: subjects, enrollments, attendance, examinations, results,
-- fees, admissions, assignments, timetable, notices, news, events, gallery,
-- library_books, book_issues, notifications, messages, settings.

CREATE DATABASE IF NOT EXISTS college_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE college_system;

-- Reference table for the four academic programs
CREATE TABLE programs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,   -- FCS, ICS, PRE_ENG, PRE_MED
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO programs (code, name) VALUES
    ('FCS', 'Faculty of Computer Science'),
    ('ICS', 'Intermediate in Computer Science'),
    ('PRE_ENG', 'FSc Pre-Engineering'),
    ('PRE_MED', 'FSc Pre-Medical');

-- Central identity table. Every login lives here; role decides which profile
-- table below applies.
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'teacher', 'student') NOT NULL,
    status ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE admins (
    user_id INT PRIMARY KEY,
    designation VARCHAR(100) DEFAULT 'Administrator',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE teachers (
    user_id INT PRIMARY KEY,
    employee_id VARCHAR(30) NOT NULL UNIQUE,
    qualification VARCHAR(150),
    designation VARCHAR(100),
    phone VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE students (
    user_id INT PRIMARY KEY,
    registration_no VARCHAR(30) NOT NULL UNIQUE,
    program_id INT NOT NULL,
    session_year VARCHAR(20),          -- e.g. 2025-2027
    phone VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (program_id) REFERENCES programs(id)
);

-- Refresh tokens back JWT auth so sessions can be revoked on logout.
CREATE TABLE refresh_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(500) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
